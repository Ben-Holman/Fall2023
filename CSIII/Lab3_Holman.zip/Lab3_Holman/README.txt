COMPILATION INSTRUCTIONS:
'make' compiles and links the program to give you the object and executable files. 

make clean removes them

I had to recompile my header(s) because there was an error in my program, but recompiling them solved that problem. 
