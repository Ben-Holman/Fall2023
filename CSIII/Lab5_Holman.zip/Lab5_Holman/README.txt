
COMPILATION INSTRUCTIONS

'make' creates the object files and executables 

'clean' removes the object files and executables
