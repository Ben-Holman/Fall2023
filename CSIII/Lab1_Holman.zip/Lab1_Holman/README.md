Compilation Instructions:

make = will generate the executable 

./main argv[1]<FILENAME> argv[2]<FILENAME> [Enter]

output

make clean will clear the object files and the executable 
