Ben Holman Midterm-2

INSTRUCTIONS: 

EXERCISE 1:
  commands: 'make' ./main file1.txt th

EXERCISE 2: 
  commands: 'make' ./main file1.txt 3 
  the C and Object files are different names for this one because I had 2 terminals open working on the same file so I renamed it to not get any weird errors. 

EXERCISE 3:
  commands: 'make' ./main file1.txt 3 15

these are the files and parameters I tested with as given in the outline. 
