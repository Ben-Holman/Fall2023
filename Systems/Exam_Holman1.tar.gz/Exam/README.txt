Ben Holman Midterm-1:


COMPILATION INSTRUCTIONS: 

run the 'make' command in the terminal to generate the object files and executable

run the 'make clean' command to remove the object and executable files.

these programs were written and compiled using the Ubuntu gcc compiler version 12.3.0
 
