#include <stdio.h>

int convertToHex(int num); 

int main(void){
int num; 
printf("Enter a Number: \n"); 
scanf("%d", &num);
printf("Your number %d \n", num);
printf("Hexidecimal Representation: %x \n", num); 
return 0; 
}

