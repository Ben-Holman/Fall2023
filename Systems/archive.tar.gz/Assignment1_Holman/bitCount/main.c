#include <stdio.h>


int main(void){
//bool isFound; 

int i, j, k; 
printf("Enter a Integer Value: "); 
scanf("%d", &j); 
for(i = 31; i>=0; i--){
    if(j&(1<<i)){
      k++; 
      printf("1"); 
    }
    else{
      printf("0");
    }
  }
printf("\n"); 
printf("the number of 1-bits found in the binary number is: %d \n", k); 
printf("\n"); 
  
return 0; 

} 
