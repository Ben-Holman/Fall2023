#include <stdio.h>


int main(void){

int i, j; 
printf("Enter a Integer Value: "); 
scanf("%d", &j); 
for(i = 31; i>=0; i--){
    if(j&(1<<i)){
      printf("1"); 
    }
    else{
      printf("0");
    }
  }
printf("\n"); 
  
return 0; 

} 
